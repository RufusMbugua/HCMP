<div id="footer_text">
	Government of Kenya &copy; <?php echo date('Y');?>. All Rights Reserved
	
</div>
