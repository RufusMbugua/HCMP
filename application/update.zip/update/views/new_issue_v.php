<?php $this->load->helper('url');?>
<script>
	json_obj = {
				"url" : "<?php echo base_url().'Images/calendar.gif';?>",
				};
	var baseUrl=json_obj.url;
	
	$(function() {
		$( "#dialog" ).dialog();
		
		$("#accordion").accordion({
			autoHeight : false,
			collapsible: true,
			active: false
		});
		
		$( "#datepicker" ).datepicker({
			showOn: "button",
			dateFormat: 'yy-mm-dd', 
			buttonImage: baseUrl,
			buttonImageOnly: true
		});
		
		
	});
	 

</script>
<style>
	td {
		padding: 5px;
	}
</style>
<?php 
     echo form_open('order_management/issueInsert'); ?>
<div align="center">
	<table>
		<tr>
			<td>Service Point</td>
			<td>
				<select>
					<option>OPD</option> 
					<option>MCH</option> 
					<option>FP/RH Clinic</option> 
					<option>Maternity</option> 
					<option>CCC</option> 
					<option>Female Ward</option> 
					<option>Male Ward</option> 
					<option>Paediatric Ward</option> 
					<option>Laboratory</option> 
					<option>Other</option> 
				</select>
			</td>
		
			<td>S11 No</td>
			<td>
				<input type="text" placeholder="enter a numerical value" />
			</td>
			<td>Date of issue</td>
			<td>			 
				<?php 
					$this->load->helper('date');
					$today= standard_date('DATE_ATOM', time()); //get today's date in full
					$today=substr($today,0,9); //get the YYYY-MM-dd format of the date above								
				?>
				<input type="text" name="datepicker" readonly="readonly" value="<?php echo $today;?>" id="datepicker"/>			
			</td>
		</tr>
	</table>
</div>

<div class="demo" style="margin: 10px;">
	
	<div id="accordion">
		<?php if(isset($popout)){?>
    <div id="dialog" title="System Message">
    <p><?php echo $popout;?></p>
   </div>
   <?php } ?>
		<?php
		foreach($drug_categories as $category){?>
			<h3><a href="#"><?php echo $category->Category_Name?></a></h3>
			<div>
			<p>
				<table>
					<tr>
						<td><b>KEMSA Code</b></td><td><b>Description</b></td><td><b>Quantity Issued</b></td>
					</tr>
					<?php
						foreach($category->Category_Drugs as $drug){?>
						<tr>
							<td><?php echo $drug->Kemsa_Code;?></td><td><?php echo $drug->Drug_Name;?></td><td>
								<?php echo form_hidden('kemsaCode[]', $drug->Kemsa_Code);?>
								<input type="text"  name="qty[]" value="0" /></td>
						</tr>
						<?php
						}
					?>
				</table>
			</p>
		</div>
		<?php }
		?>
	</div>
	<table style="font-family: Helvetica, Arial, sans-serif;">
		<tr>
			<td><b> Total Drugs Issued</b></td><td><b>10000 </b></td>
		</tr>
	</table>
	<input type="submit" class="    button "  value="Issue" >
</div><!-- End demo -->