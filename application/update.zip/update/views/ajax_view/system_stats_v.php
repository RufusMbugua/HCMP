<div style="display: table-row;  ">
    			<div style="display: table-cell;padding-bottom: 2em; ">
      				<label style=" font-weight: ">Total No of Facilities in The <?php echo $stats['option']; ?> </label>
            			    				</div>
    				<div style="display: table-cell;padding-bottom: 2em">
      				<a class="link" href="#" ><?php echo $stats['total_facilities']; ?></a>
    				</div>
  				</div>
  				
  				<div style="display: table-row; ">
    			<div style="display: table-cell;padding-bottom: 2em">
      				<label style="font-weight: ">Total No of Facilities in The <?php echo $stats['option']; ?> Using HCMP </label>
            		</div>
    				<div style="display: table-cell;padding-bottom: 2em">
      				<a class="link" href="#" ><?php echo $stats['total_facilities']; ?></a>
    				</div>
  				</div>
  				
  				<div style="display: table-row;">
    			<div style="display: table-cell; padding-bottom: 2em">
      				<label style="font-weight: ">Total No of Users in The <?php echo $stats['option']; ?></label>
            		     				</div>
    				<div style="display: table-cell;padding-bottom: 2em">
      				<a class="link" href="#" ><?php echo $stats['no_of_users']; ?></a>
    				</div>
  				</div>
  				<div style="display: table-row;">
    			<div style="display: table-cell; padding-bottom: 2em">
      				<label style="font-weight: ">Total No of Users in The <?php echo $stats['option']; ?> Accessing HCMP in The last 7 days</label>
            		     				</div>
    				<div style="display: table-cell;padding-bottom: 2em">
      				<a class="link" href="#" ><?php echo $stats['no_of_users_last_7_days']; ?></a>
    				</div>
  </div>